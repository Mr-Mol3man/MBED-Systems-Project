// Header Files
#include "mbed.h"
#include "MCP23017.h"
#include "WattBob_TextLCD.h"
#include "globals.h"
#include "VL6180.h"
#include "InterruptIn.h"

//#include "CardReader.h"
#include "TCS3472_I2C.h"

#define IDENTIFICATIONMODEL_ID 0x0000

//Pin I/O
DigitalOut myled(LED1); //led on board

SPI spi(p5, p6, p7); // mosi, miso, sclk
DigitalOut cs(p8);

VL6180  TOF_sensor(p28, p27);   //distance sensor
//TCS3472_I2C rgb_sensor(p9, p10);    //colour sensor
TCS3472_I2C rgb_sensor(p28, p27);

MCP23017            *par_port; //LCD
WattBob_TextLCD     *lcd;

Serial      pc(USBTX, USBRX); //Serial Coms

DigitalIn CardIn (p11); // card reader
AnalogIn CardLDR1 (p15);
AnalogIn CardLDR2 (p16);
AnalogIn CardLDR3 (p17);
AnalogIn CardLDR4 (p18);

InterruptIn Switch1 (p21); //button inputs
InterruptIn Switch2 (p22);
InterruptIn Switch3 (p23);
InterruptIn LDR1 (p24);
InterruptIn LDR2 (p25);
InterruptIn Slider1 (p26);
InterruptIn Slider2 (p30);


//Global Variables
uint8_t    dist;
int SPICommand;
int SPIIn;
int rgb_readings[4];
//int SWPress;

char cmd_str[CMD_STR_BUFFER_SZ]; //input sting

uint32_t cmd_code;
uint32_t param[4];
uint32_t nos_params;

uint32_t result_data[5];
uint32_t    nos_data;

int LDR1Out;
int LDR2Out;
int LDR3Out;
int LDR4Out;

//int ON;

  //int b = 1;


//Initialise system
void init_sys(void)
{
    
    par_port = new MCP23017(p9, p10, 0x40);//sets lcd
    lcd = new WattBob_TextLCD(par_port);    //sets lcd

    par_port->write_bit(1,BL_BIT);   // turn LCD backlight ON
    lcd->cls();
    lcd->locate(0,0);
    lcd->printf("Maintanace Mode");

   // pc.baud(115200);  // needed for c#app
    
    
    
return;
}

//read serial command
uint32_t get_cmd()
{
    char   ch;
    uint8_t  i;

    for (i= 0  ; i < CMD_STR_BUFFER_SZ ; i++) {
        ch = pc.getc();
        if (ch == '#') {
            continue;
        }
        cmd_str[i] = ch;
        if (ch == ';') {
            cmd_str[i] = '\0';
            break;
        }
    }

    //command->result_status = OK; dont know if i need
    return 0;
}

//Parse Command
uint32_t parse_cmd()
{
    uint8_t  param_cnt, i, state;
    uint16_t tmp;

    cmd_code = cmd_str[1];
    param_cnt = 0;
    tmp = 0;
    state = 0;
    for (i=2 ; i < CMD_STR_BUFFER_SZ ; i++) {    // step through characters

        if (cmd_str[i] == '\0') {
            if (state == 2) {     // count paramter that is terminated by NEWLINE
                param[param_cnt] = tmp;
                param_cnt++;
            }
            nos_params = param_cnt;
            return OK;
        }


        if ((cmd_str[i] == ':') && (state == 0)) {        // skip :
            continue;
        }

        if ((cmd_str[i] == ':') && (state == 1)) {        // skip :
            state = 0;
            param[param_cnt] = tmp;
            param_cnt++;
            tmp = 0;
            continue;
        }
        //

        if ((cmd_str[i] == ':') && (state == 2)) {        // skip :
            state = 0;
            param[param_cnt] = tmp;
            param_cnt++;
            tmp = 0;
            continue;
        }
        state = 1;
        state = 2;
        if ((cmd_str[i] >= '0') && (cmd_str[i] <= '9')) {
            tmp = (tmp * 10) + (cmd_str[i] - '0');
        }

        else {
            param[param_cnt] = tmp;
            return;
        }

    }
    return;
}

//Process command
uint32_t process_cmd()
{
    switch (cmd_code) {

        case SERVO_CMD :    // move a servo
            nos_data = 0;                   // no data to be returned,check that parameters are Ok
            if (nos_params != 3) {          // check for 3 parameters
                break;
            }

            switch (param[0]) {  // implement servo move to all servos
                case 1 :
                    SPICommand = (param[1])+64;
                    break;
                case 2:
                    SPICommand = (param[1])+154;
                    break;

            }
            break;

        case MOTOR_CMD :    // move motor
            nos_data = 0;                   // no data to be returned

            if (nos_params != 3) {          // check for 3 parameters
                break;
            }

            SPICommand = 16;
            SPICommand += (param[0]);

            switch (param[1]) {
                case 0 :
                    SPICommand +=0;
                    break;
                case 1 :
                    SPICommand +=4;
                    break;
                case 2 :
                    SPICommand +=8;
                    break;
                case 3 :
                    SPICommand +=12;
                    break;
            }

            switch (param[2]) {
                case 1 :
                    SPICommand +=0;
                    break;
                case 2 :
                    SPICommand +=2;
                    break;
            }
            break;


        case LED_CMD :
            nos_data = 0;                   // no data to be returned

            if (nos_params != 3) {          // check for 3 parameters
                break;
            }

            if(param[1]==1) {
                SPICommand = 48;
            } else {
                SPICommand = 32;
            }
            SPICommand += (param[0]);
            break;


        case READDIST_CMD : // return distance sensor value
            nos_data = 1;
            TOF_sensor.VL6180_Init(); //initailises distance sensor
            dist = TOF_sensor.getDistance();                // no data to be returned
            result_data[0] = dist ;
            pc.printf("#d:%d;", dist); //might not need could use the send function
            break;

        case READLDR_CMD:   //returns LDR values

            nos_data = 1;
            pc.printf("#%d:%d:%d:%d; ", CardLDR1.read(), CardLDR2.read(), CardLDR3.read(), CardLDR4.read());
          // pc.printf("#%d:%d:%d:%d; ", LDR1Out, LDR2Out, LDR3Out, LDR4Out);
            break;

        case READCOLOUR:
            nos_data =1;
            rgb_sensor.enablePowerAndRGBC();
            rgb_sensor.setIntegrationTime(100);
            rgb_sensor.getAllColors(rgb_readings);
            pc.printf("#c:%d:%d:%d:%d;\r\n",rgb_readings[0], rgb_readings[1], rgb_readings[2],rgb_readings[3]); //code, red, green, blue, clear 
            
            break;
            
      
        default:
            nos_data = 0;                   // no data to be returned

            break;
    }


    return  OK;
}

//send data
void send_data()
{
    char buffer[80];
    uint8_t i;

    pc.printf("#%d: ;", result_data[1]);
    return;
}
//card reader
void read_number()
{

  //  FOREVER {

     //   if (CardIn == 1)
      //  {

            if(CardLDR1.read() > 0.4f) {
                LDR1Out = 1;
            } else {
                LDR1Out = 0;
            }

            if(CardLDR2.read() > 0.4f) {
                LDR2Out = 1;
            } else {
                LDR2Out = 0;
            }

            if(CardLDR3.read() > 0.4f) {
                LDR3Out = 1;
            } else {
                LDR3Out = 0;
            }

            if(CardLDR4.read() > 0.4f) {
                LDR4Out = 1;
            } else {
                LDR4Out = 0;
            }
            //return;
      //  }
    //}
}

//interupt switch
void SW1()
{
    // int ON,
    int SW1P;
    SW1P=Switch1.read(); //Debouncing variable
    wait_ms(50);
    if (SW1P==Switch1.read()) {//Check for debouncing
              pc.printf("#sw1;");
    }
}

void SW2()
{
    // int ON,
    int SW2P;
    SW2P=Switch2.read(); //Debouncing variable
    wait_ms(50);
    if (SW2P==Switch2.read()) {//Check for debouncing
              pc.printf("#sw2;");
    }
}

void SW3()
{
    // int ON,
    int SW3P;
    SW3P=Switch3.read(); //Debouncing variable
    wait_ms(50);
    if (SW3P==Switch3.read()) {//Check for debouncing
              pc.printf("#sw3;");
    }
}

void L1()
{
    // int ON,
    int LDR1P;
    LDR1P=LDR1.read(); //Debouncing variable
    wait_ms(50);
    if (LDR1P==LDR1.read()) {//Check for debouncing
              pc.printf("#ldr1;");
    }
}

void L2()
{
    // int ON,
    int LDR2P;
    LDR2P=LDR2.read(); //Debouncing variable
    wait_ms(50);
    if (LDR2P==LDR2.read()) {//Check for debouncing
              pc.printf("#ldr2;");
    }
}

void S1()
{
    // int ON,
    int S1P;
    S1P=Slider1.read(); //Debouncing variable
    wait_ms(50);
    if (S1P==Slider1.read()) {//Check for debouncing
              pc.printf("#S1;");
    }
}

void S2()
{
    // int ON,
    int S2P;
    S2P=Slider2.read(); //Debouncing variable
    wait_ms(50);
    if (S2P==Slider2.read()) {//Check for debouncing
              pc.printf("#S2;");
    }
}

   
    
//Main Program
int main()
{
   if (Game==1) {
        GameMode();
    }

    init_sys();
    read_number();
     
    Switch1.rise(SW1);  //switch 1 press
    Switch1.fall(SW1);
    
    Switch2.rise(SW2);  //switch 2 press
    Switch2.fall(SW2);
    
    Switch3.rise(SW3);  //swich 3 press
    Switch3.fall(SW3);
   
    LDR1.rise(L1);  //LDR1 press
    LDR1.fall(L1);
    
    LDR2.rise(L2);  //LDR1 press
    LDR2.fall(L2);
         
    Slider1.rise(S1);  //Slider press
    Slider1.fall(S1);
    
    Slider2.rise(S2);  //Slider press
    Slider2.fall(S2);
    
  FOREVER {
      
      pc.baud(115200);
      
         get_cmd();
         parse_cmd();
         process_cmd();
         
     
        
       lcd->cls();
       lcd->locate(0,0);
       lcd->printf("%c, %d",cmd_code,SPICommand);



             while(1) {
                 spi.format(8,0);
                 spi.frequency(12000000);
                 cs = 0;
                 SPIIn=spi.write(SPICommand);
                 //wait(0.05);

                 cs=1;
                 // wait(0.05);

                 //
                 //waits for handshake to confirm command
                 //

                 if (SPIIn == 20) {
                     SPIIn = 0;
                     SPICommand = 0;
                     break;

                 }
             }
        
    }

}
