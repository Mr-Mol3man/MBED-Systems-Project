//
// globals.h : file to hold some general global defines, 
// =========
//
#include    "mbed.h"

#ifndef     GLOBALS_H
#define     GLOBALS_H

#define     FOREVER     for(;;)

#define     SERVO_CMD      's'
#define     LED_CMD        'l'
#define     MOTOR_CMD      'm'
#define     TEXT_CMD       'T'
#define     READDIST_CMD       'd'
#define     READSWTCH_CMD       'w'
#define     READLDR_CMD       'r'
#define     READCOLOUR      'c'
//#define     SWITCH_1      'i'


#define     CMD_STR_BUFFER_SZ       100
#define     OK       0
//
// I/O objects defined elswhere
//
extern Serial      pc;   // allows this object to be seen in all other files
extern DigitalIn CardIn;
//extern AnalogIn LDR1;
//extern AnalogIn LDR2;
//extern AnalogIn LDR3;
//extern AnalogIn LDR4;
//extern InterruptIn Switch1;

extern int SWPress;


#endif